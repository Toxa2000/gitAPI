﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace module
{
    internal class FullNameSerializator
    {
        public string value {get;set;}
       
    }

}
